f() ->
        % Comment indented weirdly for some reason.
        % Reindent this line - it should be below the previous one.
